/** Clase principal
*   Necesita de la clase Dos
*   @author Manuel Molino
*   @version 1.0
*/
package primero;

public class Uno{
	
	public static void main(String[] args){
		System.out.println("uno");
		String valor="Hola desde uno";
		Dos.imprimirDos(valor);
		
	}
}
