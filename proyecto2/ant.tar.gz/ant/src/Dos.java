/** Clase auxiliar
*   para la clase Uno
*   @author Manuel Molino
*   @version 1.0
*/

package primero;
public class Dos{
	
	public static void imprimirDos(String valor){
		System.out.println(valor);
	}
}
